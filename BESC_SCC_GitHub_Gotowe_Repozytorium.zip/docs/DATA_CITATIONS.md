# Original data acknowledgments

## email-Eu-core (Stanford SNAP)
Dataset information: https://snap.stanford.edu/data/email-Eu-core.html
Data source references listed by Stanford include Yin, Benson, Leskovec and Gleich, *Local Higher-order Graph Clustering* (KDD, 2017), and Leskovec, Kleinberg and Faloutsos, *Graph Evolution: Densification and Shrinking Diameters* (TKDD, 2007).

## CollegeMsg (Stanford SNAP)
Dataset information: https://snap.stanford.edu/data/CollegeMsg.html
Panzarasa, P., Opsahl, T. and Carley, K. M. (2009). *Patterns and dynamics of users’ behavior and interaction: Network analysis of an online community*. Journal of the American Society for Information Science and Technology, 60(5), 911–932.

## Polblogs
Adamic, L. A. and Glance, N. (2005). *The political blogosphere and the 2004 U.S. election: divided they blog*. Proceedings of LinkKDD 2005.
Dataset: https://public.websites.umich.edu/~mejn/netdata/

Third-party dataset licenses and terms must be checked at the provider sites. This repository does not redistribute the originals.
