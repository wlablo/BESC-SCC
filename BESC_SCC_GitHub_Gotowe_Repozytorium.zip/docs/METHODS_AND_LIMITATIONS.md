# Methods and limitations

## Algorithm

`src/run_besc_scc.py` constructs a protected edge set for each graph and seed. For each original nontrivial strongly connected component (SCC), it protects edges of an outward and inward spanning arborescence from a selected root. A supergraph of these protected edges, formed by **deleting** other graph edges, preserves the exact original SCC partition. The construction is classical and is not presented as a new theorem.

The BESC-SCC heuristic then greedily deletes other edges to approximately minimize a combination of weighted per-actor Jensen–Shannon divergence of outgoing contact-group distributions and deviation of outgoing edge retention rates from the target budget.

The program reports the retained-edge percentage, SCC agreement, profile divergence, group-mixing divergence, change in SEIC (used as an **evaluation outcome**, not optimized), and other metrics. Inferred CollegeMsg groups are not ground truth.

## Comparators and interpretation

Comparators named `random_SCC`, `community_quota_SCC`, `degree_SCC`, `jaccard_global_SCC`, and `local_degree_global_SCC` are **custom heuristic baselines**, not faithful replications of any specific published state-of-the-art algorithm. `entropy_only_SCC` is an ablation. `BESC_legacy` does not guarantee original strong connectivity.

Three protected-mask seeds are repeated measurements on each **fixed** network. They are not independent networks or independent observational samples. The stored results are exploratory and have not been independently audited. Results do not establish global optimality, general superiority, or prior-art novelty.

## Reproducibility requirements

For strict reproduction save: original input file checksums, exact package versions, method parameters, CPU/OS information, and full raw per-run CSVs. Runtime values vary by hardware. The input graphs are unweighted/static even when the original data have timestamps or multiple messages per pair. Results do not establish individual intent or causal effects.

## Research integrity

The present code, tests, tables, documentation and drafting were assembled with AI assistance. The author must review, validate, and take responsibility for any public claim. Research code and preliminary data analysis should not be characterized as AI only used for language correction. Consult the target journal's actual disclosure policy before submitting an article.
